const config = {
    api: 'https://jsonplaceholder.typicode.com',
    options: {
      headers: { 'content-type': 'application/json' },
    },
  };

  const httpGet = (endpoint:any) => {
    return fetch(`${config.api}${endpoint}`, {
      ...config.options,
    })
      .then((response) => handleResponse(response))
      .then((response) => response)
      .catch((error) => {
        console.error(error);
        throw Error(error);
      });
  };


  const handleResponse = (response:any) => {
    // You can handle 400 errors as well.
    if (response.status === 200) {
      return response.json();
    } else {
      throw Error( 'error');
    }
  };
  
// function handleResponse(response: Response): any {
//     throw new Error("Function not implemented.");
// }
export default { httpGet };